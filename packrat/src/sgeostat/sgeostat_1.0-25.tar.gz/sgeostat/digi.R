for (i in seq(1,37)){
maas.bank[i,1]<- - (132-maas.bank.dig[i,1])/316*4500+178500
maas.bank[i,2]<-(388-maas.bank.dig[i,2])/312*4500+329500
}
