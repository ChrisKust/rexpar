which.na<-function(data)
{
seq(along=data)[is.na(data)]
}

